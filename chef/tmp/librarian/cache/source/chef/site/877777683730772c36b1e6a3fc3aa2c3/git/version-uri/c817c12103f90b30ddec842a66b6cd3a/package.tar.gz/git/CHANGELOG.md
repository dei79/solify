## v1.0.0:

* [COOK-1152] - Add support for Mac OS X
* [COOK-1112] - Add support for Windows

## v0.10.0:

* [COOK-853] - Git client installation on CentOS

## v0.9.0:

* Current public release.
